#include <stdio.h>
#include <dirent.h>
#include <sys/stat.h>

int main(int argc, char *argv[]){

	DIR * dp;
	struct dirent * dirp;

	char * ptr;
	struct stat buf;
	
	if(argc != 2){
		printf("Usage : is directory name\n");
		return -1;
	}

	if((dp = opendir(argv[1])) == NULL){
		printf("Cant' Open %s\n", argv[1]);
	}


	while((dirp = readdir(dp)) != NULL){
		printf("%s \n", dirp->d_name);
	
		if(lstat(dirp->d_name, &buf) < 0){
			printf("lstat Error!\n");
			continue;
		}
	}

	closedir(dp);
	
	return 0;
}
